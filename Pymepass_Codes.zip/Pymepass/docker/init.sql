-- PymePass Database Schema
-- PostgreSQL initialization script

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Empresas (Companies)
CREATE TABLE IF NOT EXISTS empresas (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    nombre VARCHAR(255) NOT NULL,
    rnc VARCHAR(11) UNIQUE NOT NULL,
    sector VARCHAR(100),
    fecha_registro TIMESTAMP DEFAULT NOW(),
    activa BOOLEAN DEFAULT TRUE
);

-- Transacciones 606 (Compras/Gastos)
CREATE TABLE IF NOT EXISTS transacciones_606 (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id UUID REFERENCES empresas(id),
    ncf VARCHAR(20) NOT NULL,
    proveedor_rnc VARCHAR(11),
    monto DECIMAL(15, 2) NOT NULL,
    itbis DECIMAL(15, 2) DEFAULT 0,
    fecha DATE NOT NULL,
    tipo_gasto VARCHAR(50),
    estado VARCHAR(20) DEFAULT 'pendiente',
    created_at TIMESTAMP DEFAULT NOW()
);

-- Transacciones 607 (Ventas/Ingresos)
CREATE TABLE IF NOT EXISTS transacciones_607 (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id UUID REFERENCES empresas(id),
    ncf VARCHAR(20) NOT NULL,
    cliente_rnc VARCHAR(11),
    monto DECIMAL(15, 2) NOT NULL,
    itbis DECIMAL(15, 2) DEFAULT 0,
    fecha DATE NOT NULL,
    tipo_venta VARCHAR(50),
    tipo_ingreso VARCHAR(20) DEFAULT 'contado',
    estado VARCHAR(20) DEFAULT 'emitida',
    fecha_vencimiento DATE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- KPIs históricos
CREATE TABLE IF NOT EXISTS kpis_historicos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id UUID REFERENCES empresas(id),
    periodo DATE NOT NULL,
    capital_trabajo DECIMAL(15, 2),
    ratio_circulante DECIMAL(5, 4),
    flujo_caja DECIMAL(15, 2),
    ingresos_reales DECIMAL(15, 2),
    gastos_operativos DECIMAL(15, 2),
    score_crediticio INTEGER,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Evaluaciones IA
CREATE TABLE IF NOT EXISTS evaluaciones_ia (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    empresa_id UUID REFERENCES empresas(id),
    pregunta TEXT NOT NULL,
    respuesta TEXT,
    modelo VARCHAR(50) DEFAULT 'llama3',
    fecha TIMESTAMP DEFAULT NOW(),
    tokens_usados INTEGER
);

-- Sample data
INSERT INTO empresas (nombre, rnc, sector) VALUES
    ('xxxxxxxxxxxxxxxx', '101000001', 'Comercio'),
    ('xxxxxxxxxxxxxxxx', '101000002', 'Servicios'),
    ('xxxxxxxxxxxxxxxx', '101000003', 'Manufactura')
ON CONFLICT (rnc) DO NOTHING;
