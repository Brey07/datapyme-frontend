# 📋 documentacion.md — PymePass

## Ecosistema Financiero Integral para MIPYMES Dominicanas

> **Versión:** 1.0.0 | **Fecha:** Diciembre 2024 | **Normativa:** DGII · Ley 172-13 RD

---

## 1. Visión General

**PymePass** es una plataforma web full-stack diseñada para atacar la **mortalidad temprana de MIPYMES dominicanas** causada por la falta de control de liquidez. Integra un CMS, ERP y CRM financieros, orquestados por **n8n** y potenciados por **Inteligencia Artificial local** (Ollama/LLaMA).

El sistema procesa los reportes fiscales de la **Dirección General de Impuestos Internos (DGII)** — Formatos 606 (compras) y 607 (ventas) — y los convierte en inteligencia de supervivencia empresarial.

---

## 2. Arquitectura del Sistema

```mermaid
graph TB
    subgraph Frontend["🖥 Frontend — React + Vite (Puerto 5173)"]
        CMS["CMS Portal\n- Upload DGII 606/607\n- CFO Virtual Chatbot\n- Pasaporte Financiero"]
        ERP["ERP Motor\n- Dashboard KPIs\n- Cuentas por Pagar\n- Cuentas por Cobrar"]
        CRM["CRM Riesgo\n- Pipeline Cobranza\n- Scoring Proveedores\n- Prep. Crediticia"]
    end

    subgraph Docker["🐳 Docker Network: pymepass-network"]
        N8N["⚙ n8n\nOrquestador ETL\nPuerto 5678"]
        OLLAMA["🤖 Ollama\nLLaMA 3 Local\nPuerto 11434"]
        POSTGRES["🐘 PostgreSQL\nBase de Datos\nPuerto 5432"]
    end

    subgraph DGII["🏛 DGII (Fuente de Datos)"]
        F606["Formato 606\nCompras/Gastos"]
        F607["Formato 607\nVentas/Ingresos"]
    end

    CMS -->|"CSV Upload"| N8N
    N8N -->|"Anonimiza + Transforma"| OLLAMA
    N8N -->|"Inserta datos"| POSTGRES
    POSTGRES -->|"Consultas"| ERP
    POSTGRES -->|"Consultas"| CRM
    OLLAMA -->|"Respuestas XAI"| CMS
    DGII --> CMS
```

---

## 3. Módulos del Sistema

### 3.1 CMS — Portal de Transparencia Financiera

El "Front-Desk" financiero de la empresa.

| Componente | Ruta | Descripción |
|-----------|------|-------------|
| Upload DGII | `/cms/upload` | Drag & drop para CSV del Formato 606 y 607 |
| CFO Virtual | `/cms/chatbot` | Chatbot financiero vía Ollama/LLaMA |
| Pasaporte Financiero | `/cms/pasaporte` | Perfil de solvencia exportable |

**Portal de Carga Tributaria (DGII):**
- Acepta archivos `.csv` exportados desde la Oficina Virtual DGII
- Valida estructura y NCFs automáticamente
- Pipeline ETL en n8n: recepción → validación → anonimización → JSON → ingesta ERP

### 3.2 ERP — Motor Contable y de Liquidez

Núcleo duro de PymePass. Los datos fiscales se convierten en inteligencia de supervivencia.

| Componente | Ruta | Descripción |
|-----------|------|-------------|
| Dashboard ERP | `/erp` | KPIs globales + gráficas de ingresos/gastos |
| Cuentas por Pagar | `/erp/pagar` | NCFs del 606 — presión de deuda CP |
| Cuentas por Cobrar | `/erp/cobrar` | NCFs del 607 — efectivo real vs crédito |
| KPIs Duros | `/erp/kpis` | Métricas financieras para banca dominicana |

**KPIs calculados automáticamente:**

```
Capital de Trabajo Operativo = Ingresos Reales − Costos Operativos
Ratio Circulante (RC)        = Activos Corrientes ÷ Pasivos Inminentes
Margen Bruto (%)             = (Ingresos − COGS) ÷ Ingresos × 100
Flujo de Caja Libre          = Flujo Operativo − Inversiones de Capital
```

> ⚠ **ALERTA CRÍTICA:** Si el Ratio Circulante < 1.05, el sistema activa alerta inmediata de riesgo de insolvencia.

### 3.3 CRM — Gestión de Riesgo Comercial

El CRM de PymePass no vende más — **cobra a tiempo y gestiona el riesgo**.

| Componente | Ruta | Descripción |
|-----------|------|-------------|
| Pipeline Cobranza | `/crm/cobranza` | Kanban: Facturado → Vencido → Cobrado |
| Scoring Proveedores | `/crm/proveedores` | Evaluación de riesgo de suplidores (del 606) |
| Prep. Crediticia | `/crm/credito` | Embudo de Loan Readiness para bancos dominicanos |

### 3.4 Orquestador n8n

| Workflow | Descripción |
|---------|-------------|
| ETL DGII 606/607 | Extrae y transforma los CSVs cargados en CMS |
| Filtro Anonimización Zero-Bias | Elimina PII antes de enviar datos a Ollama |
| Alertas Cobranza Auto | Automatiza recordatorios de pago a clientes |
| Generador Pasaporte Financiero | Compila el perfil de solvencia |
| Sincronización KPIs → DB | Persiste métricas calculadas en PostgreSQL |
| Reporte Semanal Automático | Genera y envía reportes periódicos |

### 3.5 IA Financiera — Evaluador Zero-Bias

Implementado con **Ollama** corriendo localmente, modelo **LLaMA 3**.

**Principios del Sistema:**
- **Zero-Bias System Prompting:** La IA evalúa únicamente ratios y flujos numéricos
- **Anonimización previa (n8n):** Nombre, género y razón social son eliminados antes del análisis
- **Explicabilidad (XAI):** Cada respuesta incluye el cálculo paso a paso
- **Alertas automáticas:** RC < 1.05 → alerta de quiebra inmediata
- **IA Local:** Ningún dato financiero sale al exterior — Cumplimiento Ley 172-13

---

## 4. Stack Tecnológico

### Frontend
| Tecnología | Versión | Uso |
|-----------|---------|-----|
| React | 18.3.x | Framework UI |
| Vite | 6.x | Build tool + dev server |
| React Router DOM | 6.x | Client-side routing |
| Recharts | 2.x | Gráficas financieras |
| Lucide React | 0.468 | Iconografía |
| Framer Motion | 11.x | Animaciones |

### Backend / Infraestructura (Docker)
| Servicio | Imagen | Puerto | Descripción |
|---------|--------|--------|-------------|
| frontend | Dockerfile (Node 20 → Nginx) | 5173 | React SPA |
| n8n | n8nio/n8n:latest | 5678 | Orquestador workflows |
| ollama | ollama/ollama:latest | 11434 | IA local LLaMA 3 |
| postgres | postgres:16-alpine | 5432 | Base de datos principal |

---

## 5. Estructura del Proyecto

```
Pymepass/
├── 📄 docker-compose.yml        # Orquestación de servicios Docker
├── 📄 Dockerfile                # Multi-stage: Node build → Nginx serve
├── 📄 nginx.conf                # SPA routing + headers de seguridad
├── 📄 .env                      # Variables de entorno (Docker hostnames)
├── 📄 .env.example              # Plantilla de variables de entorno
├── 📄 package.json              # Dependencias NPM
├── 📄 vite.config.js            # Configuración Vite (host 0.0.0.0)
├── 📄 index.html                # Entry point HTML + Google Fonts
├── 📄 documentacion.md          # Este archivo
│
├── 📁 docker/
│   └── init.sql                 # Esquema inicial PostgreSQL
│
└── 📁 src/
    ├── main.jsx                 # Punto de entrada React
    ├── App.jsx                  # Router principal (13 rutas)
    ├── index.css                # Design System completo (CSS Variables)
    │
    ├── 📁 data/
    │   └── mockData.js          # Datos demo: empresa, 606/607, KPIs, proveedores
    │
    ├── 📁 components/
    │   └── layout/
    │       ├── Sidebar.jsx      # Navegación lateral fija
    │       ├── Header.jsx       # Top bar con semáforo financiero
    │       └── Footer.jsx       # Pie de página
    │
    └── 📁 pages/
        ├── Overview.jsx         # Dashboard principal (ruta /)
        ├── cms/
        │   ├── UploadDGII.jsx   # Carga 606/607
        │   ├── ChatbotFinanciero.jsx  # CFO Virtual
        │   └── PasaporteFinanciero.jsx # Pasaporte de solvencia
        ├── erp/
        │   ├── ERPDashboard.jsx # Dashboard ERP
        │   ├── CuentasPagar.jsx # Formato 606
        │   ├── CuentasCobrar.jsx # Formato 607
        │   └── KPIsDuros.jsx   # Métricas financieras
        ├── crm/
        │   ├── PipelineCobranza.jsx  # Kanban cobranza
        │   ├── ScoringProveedores.jsx # Scoring suplidores
        │   └── PreparacionCrediticia.jsx # Loan Readiness
        ├── orchestrator/
        │   └── N8NDashboard.jsx # Estado workflows n8n
        └── ai/
            └── AIFinanciera.jsx # Evaluador Zero-Bias
```

---

## 6. Base de Datos (PostgreSQL)

### Tablas Principales

```sql
empresas               -- Registro de MIPYMES (RNC)
transacciones_606      -- Compras y gastos (NCF, proveedor, monto, ITBIS)
transacciones_607      -- Ventas e ingresos (NCF, cliente, monto, tipo: contado/crédito)
kpis_historicos        -- Series temporales de KPIs por empresa
evaluaciones_ia        -- Historial de consultas al modelo Ollama
```

### Índices de Seguridad
- Los datos de `transacciones_606` y `transacciones_607` se anonymizan en n8n **antes** de enviarse a Ollama
- La tabla `empresas` nunca es accedida por el modelo de IA
- Cumplimiento con **Ley 172-13 de Protección de Datos Personales** de la República Dominicana

---

## 7. Flujo de Datos ETL (n8n)

```
   DGII CSV                n8n Workflow                  ERP / IA
┌───────────┐    ┌─────────────────────────────┐    ┌──────────────┐
│ 606.csv   │───►│ 1. Recepción del archivo    │    │              │
│ 607.csv   │    │ 2. Validar NCF y estructura │    │  PostgreSQL  │
└───────────┘    │ 3. Eliminar PII (nombre,    │───►│  (KPIs,      │
                 │    género, razón social)     │    │  606, 607)   │
                 │ 4. Calcular KPIs            │    └──────────────┘
                 │ 5. Empaquetar en JSON       │         │
                 │ 6. Insertar en PostgreSQL   │         │
                 │ 7. Enviar resumen a Ollama  │───►  Ollama IA
                 └─────────────────────────────┘   (datos anon.)
```

---

## 8. Variables de Entorno

| Variable | Desarrollo | Docker |
|----------|-----------|--------|
| `VITE_N8N_URL` | `http://localhost:5678` | `http://n8n:5678` |
| `VITE_OLLAMA_URL` | `http://localhost:11434` | `http://ollama:11434` |
| `POSTGRES_USER` | `pymepass` | `pymepass` |
| `POSTGRES_PASSWORD` | _(cambiar)_ | `pymepass_secret` |
| `POSTGRES_DB` | `pymepass_db` | `pymepass_db` |

---

## 9. Instrucciones de Despliegue

### 9.1 Con Docker (Recomendado)

```bash
# 1. Clonar y entrar al directorio
cd Pymepass

# 2. Copiar variables de entorno
cp .env.example .env

# 3. Levantar todos los servicios
docker-compose up -d

# 4. Ver logs
docker-compose logs -f

# 5. Acceder a los servicios:
#    Frontend:  http://localhost:5173
#    n8n:       http://localhost:5678  (admin / pymepass123)
#    Ollama:    http://localhost:11434
#    PostgreSQL: localhost:5432
```

### 9.2 Descargar modelo LLaMA en Ollama

```bash
# Una vez que el contenedor Ollama esté corriendo:
docker exec -it pymepass-ollama-1 ollama pull llama3
```

### 9.3 Desarrollo Local (sin Docker)

```bash
npm install
npm run dev
# App disponible en http://localhost:5173
```

---

## 10. Normativa y Cumplimiento

| Normativa | Aplicación en PymePass |
|-----------|------------------------|
| **Ley 172-13** (RD) | IA local, anonimización de PII, no transferencia internacional de datos |
| **DGII — Formato 606** | Ingesta, validación y análisis de NCF de compras |
| **DGII — Formato 607** | Ingesta, validación y análisis de NCF de ventas |
| **NCF (Núm. Comprobante Fiscal)** | Validados en pipeline ETL y almacenados en PostgreSQL |
| **Banca Dominicana** | KPIs y score crediticio calibrados para requisitos locales |

---

## 11. Glosario Financiero

| Término | Definición |
|---------|-----------|
| **Ratio Circulante (RC)** | Activos corrientes / Pasivos inminentes. RC ≥ 1.05 = zona segura |
| **Capital de Trabajo** | Diferencia entre activos y pasivos corrientes |
| **Cash-Crunch** | Estrangulamiento de caja por exceso de facturas a crédito no cobradas |
| **NCF** | Número de Comprobante Fiscal — identificador único de factura DGII |
| **Zero-Bias** | Evaluación financiera sin sesgos demográficos (género, nombre, etnia) |
| **XAI** | Explainable AI — respuestas con cálculos visibles paso a paso |
| **606** | Formato DGII de declaración de compras y gastos mensuales |
| **607** | Formato DGII de declaración de ventas e ingresos mensuales |
| **Loan Readiness** | Nivel de preparación de la empresa para acceder a crédito bancario |
| **Pasaporte Financiero** | Perfil de solvencia validado y compartible de la MIPYME |

---

*Documentación generada para PymePass v1.0.0 — Ecosistema Financiero MIPYME República Dominicana*
