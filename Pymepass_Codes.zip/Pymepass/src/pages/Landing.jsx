import React, { useState } from 'react';

export default function Landing({ onLogin }) {
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    // Simulate login delay
    setTimeout(() => {
      onLogin();
    }, 800);
  };

  return (
    <div className="landing-container">
      {/* Background Image - Financial Theme from Unsplash */}
      <div className="landing-bg" style={{
        backgroundImage: 'url("https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2426&auto=format&fit=crop")',
        backgroundSize: 'cover',
        backgroundPosition: 'center',
        position: 'absolute',
        top: 0, left: 0, right: 0, bottom: 0,
        zIndex: -1,
        filter: 'blur(3px) brightness(0.9)',
        transform: 'scale(1.02)'
      }} />

      {/* Main Content Card (Glassmorphism / White Transparent) */}
      <div className="landing-card animate-in" style={{
        background: 'rgba(255, 255, 255, 0.85)',
        backdropFilter: 'blur(10px)',
        width: '100%',
        maxWidth: '500px',
        height: '100vh',
        padding: '60px 40px',
        display: 'flex',
        flexDirection: 'column',
        boxShadow: '10px 0 30px rgba(0,0,0,0.1)',
      }}>
        
        {/* Logo */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: '60px' }}>
          <div style={{ 
            width: 48, height: 48, borderRadius: 12, background: 'var(--color-primary)', 
            color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center',
            fontSize: 22, fontWeight: 800, fontFamily: 'Arial'
          }}>PP</div>
          <span style={{ fontSize: 32, fontWeight: 300, color: '#333', letterSpacing: '-0.5px' }}>Pyme<span style={{fontWeight: 700}}>Pass</span></span>
        </div>

        {/* Headline with Black Highlight Style */}
        <div style={{ marginBottom: '30px', display: 'flex', flexDirection: 'column', alignItems: 'flex-start', gap: '8px' }}>
          <span style={{ background: '#111', color: 'white', padding: '4px 12px', fontSize: 36, fontWeight: 800, lineHeight: 1.1 }}>¿Falta liquidez?</span>
          <span style={{ background: '#111', color: 'white', padding: '4px 12px', fontSize: 36, fontWeight: 800, lineHeight: 1.1 }}>Tranquilo,</span>
          <span style={{ background: '#111', color: 'white', padding: '4px 12px', fontSize: 36, fontWeight: 800, lineHeight: 1.1 }}>¡Nosotros te cubrimos!</span>
        </div>

        {/* Subtitle */}
        <p style={{ color: '#555', fontSize: 15, lineHeight: 1.6, marginBottom: '40px', maxWidth: '380px' }}>
          El ecosistema financiero integrado para MIPYMES dominicanas. 
          Conecta tus reportes de la DGII, evalúa tu riesgo y prepárate para financiamiento bancario en segundos.
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '16px', maxWidth: '320px' }}>
          <input 
            type="text" 
            placeholder="RNC o Cédula" 
            required
            style={{ 
              padding: '14px', borderRadius: '4px', border: '1px solid #ccc', 
              fontSize: 14, background: 'white', outline: 'none' 
            }}
            onFocus={(e) => e.target.style.borderColor = 'var(--color-primary)'}
            onBlur={(e) => e.target.style.borderColor = '#ccc'}
          />
          <input 
            type="email" 
            placeholder="Correo electrónico" 
            required
            style={{ 
              padding: '14px', borderRadius: '4px', border: '1px solid #ccc', 
              fontSize: 14, background: 'white', outline: 'none' 
            }}
            onFocus={(e) => e.target.style.borderColor = 'var(--color-primary)'}
            onBlur={(e) => e.target.style.borderColor = '#ccc'}
          />
          <button 
            type="submit" 
            disabled={isLoading}
            style={{ 
              marginTop: '10px', padding: '14px', borderRadius: '4px', 
              background: 'var(--color-primary)', color: 'white', border: 'none', 
              fontSize: 14, fontWeight: 700, cursor: 'pointer', textTransform: 'uppercase',
              letterSpacing: '1px', alignSelf: 'flex-start', paddingLeft: '32px', paddingRight: '32px',
              opacity: isLoading ? 0.7 : 1, transition: 'all 0.2s'
            }}
          >
            {isLoading ? 'Accediendo...' : 'Ingresar'}
          </button>
        </form>

      </div>
    </div>
  );
}
