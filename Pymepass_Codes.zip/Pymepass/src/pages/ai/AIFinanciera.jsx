import { useState } from 'react';
import { Send, Bot, ShieldCheck, Brain, Eye } from 'lucide-react';

const systemPrompt = `Eres un evaluador financiero insobornable y sin sesgos (Zero-Bias). 
Evalúas MIPYMES dominicanas basándote únicamente en métricas cuantitativas.
REGLA CRÍTICA: Si el Ratio Circulante < 1.05, DEBES alertar inmediatamente sobre riesgo de insolvencia.
EXPLICABILIDAD: Siempre muestra tus cálculos paso a paso (XAI).
PRIVACIDAD: Los datos de empresa y propietario han sido anonimizados por n8n antes de llegar a ti.`;

const initialMessages = [
  {
    role: 'ai',
    content: `Sistema activado. Soy el **Evaluador Financiero Zero-Bias** de PymePass.

📊 **Estado actual del portafolio anónimo analizado:**
- Ratio Circulante: **1.38** ✅ (sobre umbral de 1.05)
- Capital de Trabajo: **RD$485,250** ✅
- Flujo de caja: **Positivo** ✅
- Score crediticio estimado: **72/100** 

**Evaluación general:** La MIPYME muestra indicadores de solvencia saludables. No se detectan banderas rojas inmediatas. Listo para consultas específicas.`
  }
];

export default function AIFinanciera() {
  const [messages, setMessages] = useState(initialMessages);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPrompt, setShowPrompt] = useState(false);

  const send = async () => {
    if (!input.trim()) return;
    const q = input;
    setInput('');
    setMessages(m => [...m, { role: 'user', content: q }]);
    setLoading(true);
    await new Promise(r => setTimeout(r, 1800));
    setMessages(m => [...m, {
      role: 'ai',
      content: `**Análisis XAI — Paso a Paso:**

**1. Carga de datos anonimizados (n8n):**
- Identidad del propietario: ~~eliminada~~
- Género: ~~eliminado~~  
- Razón social: ~~eliminada~~
- Datos financieros: ✓ conservados para análisis

**2. Cálculo automático de métricas relevantes:**
- RC = 1.38 (Activos Corrientes / Pasivos Inminentes)
- FCL = RD$124,800 (Flujo de Caja Libre neto)

**3. Aplicación de reglas de evaluación bancaria DOM:**
- RC ≥ 1.05 → ✅ Cumple umbral mínimo
- Flujo positivo → ✅ Empresa autosustentable
- Sin facturas vencidas críticas → ✅

**Conclusión:** La empresa evaluada cumple con los criterios básicos de solvencia para acceso a crédito estándar en la banca dominicana.`,
    }]);
    setLoading(false);
  };

  return (
    <div className="page-content animate-in">
      <div className="breadcrumb">
        <span>SISTEMA</span><span className="breadcrumb-sep">/</span>
        <span className="breadcrumb-current">IA FINANCIERA</span>
      </div>
      <div className="page-header">
        <div>
          <h1 className="page-title">Inteligencia Artificial Financiera</h1>
          <p className="page-subtitle">Evaluador Zero-Bias impulsado por LLaMA (Ollama local). Análisis Explicable (XAI) con cumplimiento Ley 172-13 RD.</p>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button
            className="btn btn-outline"
            onClick={() => setShowPrompt(p => !p)}
          >
            <Eye size={14} />
            {showPrompt ? 'Ocultar' : 'Ver'} System Prompt
          </button>
        </div>
      </div>

      {showPrompt && (
        <div className="card card-pad" style={{ marginBottom: 16 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 10 }}>
            <Brain size={15} color="var(--color-primary)" />
            <div className="card-title">System Prompt — Zero-Bias Evaluator</div>
          </div>
          <pre style={{
            fontFamily: 'var(--font-mono)', fontSize: 12, lineHeight: 1.8,
            color: 'var(--color-text-secondary)', whiteSpace: 'pre-wrap',
            background: 'var(--color-surface-2)', padding: 14, borderRadius: 'var(--radius-md)',
            border: '1px solid var(--color-border)',
          }}>
            {systemPrompt}
          </pre>
        </div>
      )}

      <div className="grid-2" style={{ alignItems: 'start' }}>
        <div className="card" style={{ overflow: 'hidden' }}>
          <div style={{ padding: '14px 16px', borderBottom: '1px solid var(--color-border)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: '50%', background: 'var(--color-text-primary)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Bot size={16} color="white" />
            </div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700 }}>Evaluador Zero-Bias · LLaMA 3</div>
              <div style={{ fontSize: 11, color: 'var(--color-success)', fontWeight: 600 }}>● Ollama Local · Datos Anonimizados ✓</div>
            </div>
            <div style={{ marginLeft: 'auto' }}>
              <span className="tag">XAI Activo</span>
            </div>
          </div>

          <div className="chat-messages" style={{ height: 420 }}>
            {messages.map((m, i) => (
              <div key={i} className={`chat-msg ${m.role === 'user' ? 'user' : ''}`}>
                <div className={`chat-avatar ${m.role === 'ai' ? 'ai-avatar' : ''}`}>
                  {m.role === 'ai' ? <Bot size={13} /> : '👤'}
                </div>
                <div className="chat-bubble" style={{ whiteSpace: 'pre-wrap', lineHeight: 1.7 }}>
                  {m.content}
                </div>
              </div>
            ))}
            {loading && (
              <div className="chat-msg">
                <div className="chat-avatar ai-avatar"><Bot size={13} /></div>
                <div className="chat-bubble" style={{ color: 'var(--color-text-muted)', fontStyle: 'italic' }}>
                  Procesando análisis XAI...
                </div>
              </div>
            )}
          </div>

          <div className="chat-input-bar">
            <input
              className="chat-input"
              placeholder="Solicita una evaluación financiera..."
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && send()}
            />
            <button className="btn btn-primary btn-sm" onClick={send}>
              <Send size={13} />
            </button>
          </div>
        </div>

        <div className="card card-pad">
          <div className="card-title" style={{ marginBottom: 14 }}>
            <ShieldCheck size={15} style={{ display: 'inline', marginRight: 6 }} />
            Principios Zero-Bias
          </div>
          {[
            { icon: '🔢', title: 'Solo Matemáticas', desc: 'La IA evalúa únicamente ratios y flujos. Sin inferencias sobre género, etnia o nombre.' },
            { icon: '🔒', title: 'Datos Anonimizados', desc: 'n8n elimina toda PII antes de enviar datos a Ollama. Cumple Ley 172-13.' },
            { icon: '📖', title: 'Explicabilidad (XAI)', desc: 'Cada conclusión incluye el cálculo paso a paso, educando al emprendedor.' },
            { icon: '⚡', title: 'Alertas Automáticas', desc: 'Si RC < 1.05, el sistema alerta inmediatamente sobre riesgo de insolvencia.' },
            { icon: '🏠', title: 'IA Local', desc: 'Ollama corre en tu servidor. Ningún dato financiero sale a la nube.' },
          ].map(({ icon, title, desc }) => (
            <div key={title} style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
              <span style={{ fontSize: 18 }}>{icon}</span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{title}</div>
                <div style={{ fontSize: 12, color: 'var(--color-text-secondary)', lineHeight: 1.5 }}>{desc}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
